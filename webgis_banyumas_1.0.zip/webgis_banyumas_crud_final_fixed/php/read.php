<?php
include 'db.php';
$res = $conn->query("SELECT * FROM faskes");
$data = array();
while ($row = $res->fetch_assoc()) $data[] = $row;
header('Content-Type: application/json');
echo json_encode($data);
?>