<?php
include 'db.php';
$id = $_POST['id'];
$nama = $_POST['nama'];
$jenis = $_POST['jenis'];
$lat = $_POST['lat'];
$lng = $_POST['lng'];
$conn->query("UPDATE faskes SET nama='$nama', jenis='$jenis', lat='$lat', lng='$lng' WHERE id=$id");
?>