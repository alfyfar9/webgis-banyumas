<?php
include 'db.php';
$id = $_GET['id'];
$conn->query("DELETE FROM faskes WHERE id=$id");
?>