<?php
$conn = new mysqli("localhost", "root", "", "webgis_banyumas", 3307);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>