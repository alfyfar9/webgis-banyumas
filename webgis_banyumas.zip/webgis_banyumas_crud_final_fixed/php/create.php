<?php
include 'db.php';
$nama = $_POST['nama'];
$jenis = $_POST['jenis'];
$lat = $_POST['lat'];
$lng = $_POST['lng'];
$conn->query("INSERT INTO faskes (nama, jenis, lat, lng) VALUES ('$nama', '$jenis', '$lat', '$lng')");
?>